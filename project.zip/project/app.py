from flask import Flask, request, jsonify, render_template
from google import genai
from flask_cors import CORS
import re

app = Flask(__name__)
CORS(app)

# Configure Gemini API client
client = genai.Client(api_key="AIzaSyAZyvOG2WEN8ErycLcmYJ5IPZlJkxY5prc")

# Local emotion and crisis detection
EMOTION_KEYWORDS = {
    "sadness": ["sad", "depressed", "lonely", "unhappy", "down"],
    "anger": ["angry", "frustrated", "mad", "annoyed"],
    "joy": ["happy", "excited", "joyful", "glad"],
    "fear": ["scared", "anxious", "nervous", "afraid"],
    "love": ["love", "affection", "fond"],
}

CRISIS_KEYWORDS = ["suicide", "kill myself", "self-harm", "end my life"]

history = []

def detect_emotion(text):
    for emotion, keywords in EMOTION_KEYWORDS.items():
        if any(kw in text.lower() for kw in keywords):
            return emotion
    return "neutral"

def detect_crisis(text):
    return any(re.search(rf"{kw}", text.lower()) for kw in CRISIS_KEYWORDS)

@app.route("/")
def home():
    return render_template("in.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "").strip()
    if not user_input:
        return jsonify({"response": "Please enter a valid message."})

    if detect_crisis(user_input):
        return jsonify({"response": "⚠️ It seems you might be in danger. Please contact local help or a hotline immediately."})

    emotion = detect_emotion(user_input)

    prompt = f"""
User is feeling {emotion}.
User message: "{user_input}"
Suggest one short personalized wellness activity (breathing, journaling, mindfulness) in a friendly and supportive tone.
"""

    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        model_response = response.text.strip()
    except Exception as e:
        print("Gemini API error:", e)
        model_response = "Sorry, I couldn't generate a recommendation right now."

    history.append({"role": "user", "parts": [user_input]})
    history.append({"role": "model", "parts": [model_response]})

    return jsonify({"emotion": emotion, "response": model_response})

if __name__ == "__main__":
    app.run(debug=True)
